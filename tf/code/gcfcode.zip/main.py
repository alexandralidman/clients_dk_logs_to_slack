import json
import os
from google.cloud.logging import DESCENDING, Client
import base64
import requests


def main(event, context):
    project_id = "wideops-sasha"
    pubsub_message = json.loads(base64.b64decode(event['data']).decode('utf-8')
)

    # webhook_url = os.getenv("WEBHOOK_URL")
    # slack_message = {
    #     "text": f"New Pub/Sub message: {pubsub_message}"
    # }
    # response = requests.post(webhook_url, data=json.dumps(slack_message), headers={'Content-Type': 'application/json'})




    logclient = Client(project=project_id)
    logger = logclient.logger("cloud_functions_input")
    payload = {"status":"just_the_payload", "message": json.dumps(pubsub_message["jsonPayload"])}
    logger.log_struct(payload)
    return "ok"